"""Test fixture: a project published as one ZIP file (demo.json "bundle")."""
import csv

import matplotlib.pyplot as plt

from pkg.util import smooth

WINDOW = 3     # smoothing window

with open("data/values.csv") as fh:
    values = [float(row["value"]) for row in csv.DictReader(fh)]

fig, ax = plt.subplots(figsize=(5, 3))
ax.plot(values, "o-", label="raw")
ax.plot(smooth(values, WINDOW), lw=3, label=f"window {WINDOW}")
ax.legend()
plt.show()
